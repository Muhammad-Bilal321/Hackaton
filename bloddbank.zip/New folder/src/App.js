// import './App.css';
import AppRouter from "./Config/AppRouter";
function App() {
  return (
    <>
      <AppRouter />
    </>
  );
}

export default App;
